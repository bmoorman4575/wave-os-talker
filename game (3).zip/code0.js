gdjs.crasherCode = {};
gdjs.crasherCode.GDenterObjects1= [];
gdjs.crasherCode.GDenterObjects2= [];
gdjs.crasherCode.GDfpsObjects1= [];
gdjs.crasherCode.GDfpsObjects2= [];

gdjs.crasherCode.conditionTrue_0 = {val:false};
gdjs.crasherCode.condition0IsTrue_0 = {val:false};
gdjs.crasherCode.condition1IsTrue_0 = {val:false};


gdjs.crasherCode.eventsList0 = function(runtimeScene) {

{


gdjs.crasherCode.condition0IsTrue_0.val = false;
{
gdjs.crasherCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs.crasherCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("enter"), gdjs.crasherCode.GDenterObjects1);
{runtimeScene.getVariables().getFromIndex(0).setNumber(1);
}{for(var i = 0, len = gdjs.crasherCode.GDenterObjects1.length ;i < len;++i) {
    gdjs.crasherCode.GDenterObjects1[i].setString("thissg is the example pagragraph and sgthis is ment to gdive the aisd a start to crashging your psgdcthis is the exagmdple gdparagraph and this issg gmdent to give dthe ai a start dtgod crashing your pcthigss is the gexample paragraph adnd thidgsdg digsd ment to gfdive the ai a startg dto crashingdf your sgdpcthis igs the example pgaragrfaph anddg this is ment tso gidve the aidg a start to crashisng syour pctdghis is the example psarsagraph gand this is ment to sdgive the gadi a start to crashginsg your pgcdgthis is the examdsple paragrapdgh and thgdgis is ment to give tdghe ai a ssgtart to crashing yodugr pchthis is the example paragdgrapht and this is ment to give dgthe ai a start to crashing yodgur pcthis is the example paragrdgadph and this is ment to give thgedg ai a start to crashing your dgpcthis is the example pardgagraph and this is ment to givgde the ai a start to crashing dgyour pcthis is the example pardaggraph and this is ment to givdge the ai a start to crashingdg your pcthis is the exampldeg paragraph and this is mdegnt to give the ai a start to dgcrashing your pcthis is the exadgmple paragraph and this is mengdt to give the ai a start to gdcdgrashing your pcthis is the edgxdample paragraph and this gidgs ment to give the ai a start tgo crashing your pcthis is tdhdge example paragraph and this is dgment to give the ai a start to crashing your pcthis is the exagdmple paragraph and this is mendgt to give the ai a start to gdcrashing your pcthis is thdge example paragraph and tdghis is ment to give the ai a sgdtart to crashing your pcthis gdis the example paragraph and thdgis is ment to give the ai a stgdart to crashing your pcthidgs is the example paragrapdgh and this is ment to give thegd ai a start to crashing your dgpcthis is the example paragraphgd and this is ment to give the dgadgi a start to crashing your pctdghis is the example paragrdgaph and this is ment to give the ai a start to crashing gdyour pc ");
}
}}

}


{


gdjs.crasherCode.condition0IsTrue_0.val = false;
{
gdjs.crasherCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 1;
}if (gdjs.crasherCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("enter"), gdjs.crasherCode.GDenterObjects1);
{for(var i = 0, len = gdjs.crasherCode.GDenterObjects1.length ;i < len;++i) {
    gdjs.crasherCode.GDenterObjects1[i].setString(gdjs.evtsExt__Compressor__Compress.func(runtimeScene, (gdjs.crasherCode.GDenterObjects1[i].getString()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.crasherCode.GDenterObjects1.length ;i < len;++i) {
    gdjs.crasherCode.GDenterObjects1[i].setCharacterSize(gdjs.randomFloatInRange(1, 100));
}
}{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}}

}


{


gdjs.crasherCode.condition0IsTrue_0.val = false;
{
gdjs.crasherCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.crasherCode.condition0IsTrue_0.val) {
}

}


};

gdjs.crasherCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.crasherCode.GDenterObjects1.length = 0;
gdjs.crasherCode.GDenterObjects2.length = 0;
gdjs.crasherCode.GDfpsObjects1.length = 0;
gdjs.crasherCode.GDfpsObjects2.length = 0;

gdjs.crasherCode.eventsList0(runtimeScene);
return;

}

gdjs['crasherCode'] = gdjs.crasherCode;
